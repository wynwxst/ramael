from setuptools import setup

setup(name='spyrael',
      version='0.0.1',
      description='An elegeant http requests library for python',
      url='http://github.com/Ehnryu/spyrael',
      author='Ehnryu/Sakurai07',
      author_email='blzzardst0rm@gmail.com',
      license='MIT',
      packages=['spyrael'],
    keywords=['spyrael', 'requests',"http"])